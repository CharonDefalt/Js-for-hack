# نفوذ به وب کم با جاوا اسکریپت

# نوشته شده توسط دکی تیم

سورسی برای عکس گرفتن از تارگت با فرستادن لینک سایت

### "این سورس صرفا جنبه آموزشی دارد هرگونه کپی از آن و خرید و فروش سورس غیر قانونی می باشد پی نوشت : البته تو ایران این چیزا معنی نداره ولی نکنید بیاین باهم مهربون باشیم"

### ویدیوی آموزشی این سورس

https://youtu.be/Golp-WCybQU

### چنل دیسکورد ما برای سوالات و پیشنهادات شما

https://discord.gg/GHV4BKs7nh



# `آموزش استفاده`

به ویدیو آموزشی مراجعه کنید

---------------------------------------------------------------------------------------

# Webcam Hacking (Webcam Snap) - Javascript

# By DociTeam

You can take a shot from target with his/her webcam.

### "It's for education purpose only!Be kind and do not copy and sell it!"


Supports Windows, Linux

### How-to-make-this-source Video on YouTube:

https://youtu.be/Golp-WCybQU

### Our Discord Channel For Q&A:

https://discord.gg/GHV4BKs7nh



# `Installation:`

`Just upload them on your host!`


# **Disclaimer**

I'm not responsible for damages caused with Webcam Snap, or other peoples actions with this program.


