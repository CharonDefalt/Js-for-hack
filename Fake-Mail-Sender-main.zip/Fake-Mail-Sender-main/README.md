# ارسال ایمیل با آدرس جعلی - پی اچ پی و اچ تی ام ال

# نوشته شده توسط دکی تیم

اسکریپتی برای ارسال ایمیل با آدرس های جعلی

### "این اسکریپت صرفا جنبه آموزشی دارد"



### ویدیوی آموزشی این سورس

https://youtu.be/6_vccuFRIBE

### چنل دیسکورد ما برای سوالات و پیشنهادات شما

https://discord.gg/gqhXd4f7Zx



# `آموزش نصب`

کافی است فایل پی اچ پی را در هاست خود آپلود کنید



# **توجه**

مسئولیت استفاده از این اسکریپت برعهده شما می باشد و دکی تیم هیچ مسئولیتی در قبال استفاده نامناسب و غیرقانونی شما از این اسکریپت را به عهده نمی گیرد

---------------------------------------------------------------------------------------

# Fake Mail Sender - PHP & HTML

# By DociTeam

You can send mails with fake address with this script.

### "It's for education purpose only!"



### How-to-make-this-source Video on YouTube:

https://youtu.be/6_vccuFRIBE

### Our Discord Channel For Q&A:

https://discord.gg/gqhXd4f7Zx



# `Installation:`

Just Upload PHP File On Your Host!



# **Disclaimer**

I am not responsible for any illegal things you do with this script.


