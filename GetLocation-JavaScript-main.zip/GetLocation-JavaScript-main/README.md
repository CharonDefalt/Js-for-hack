# پیدا کردن لوکیشن با کد جاوا اسکریپتی

# نوشته شده توسط دکی تیم

سورسی برای گرفتن طول و عرض جغرافیایی تارگت با فرستادن لینک سایت

### "این سورس صرفا جنبه آموزشی دارد هرگونه کپی از آن و خرید و فروش سورس غیر قانونی می باشد پی نوشت : البته تو ایران این چیزا معنی نداره ولی نکنید بیاین باهم مهربون باشیم"

### ویدیوی آموزشی این سورس

https://youtu.be/e_hunvhHviQ

### چنل دیسکورد ما برای سوالات و پیشنهادات شما

https://discord.gg/GHV4BKs7nh



# `آموزش استفاده`

به ویدیو آموزشی مراجعه کنید

---------------------------------------------------------------------------------------

# Get Location With Link - Javascript

# By DociTeam

You can get target's Latitude and Longitude By sending a link.

### "It's for education purpose only!Be kind and do not copy and sell it!"

### How-to-make-this-source Video on YouTube:

https://youtu.be/e_hunvhHviQ

### Our Discord Channel For Q&A:

https://discord.gg/GHV4BKs7nh



# `Installation:`

`Just upload them on your host!`


# **Disclaimer**

I'm not responsible for damages caused with Get Location, or other peoples actions with this program.


